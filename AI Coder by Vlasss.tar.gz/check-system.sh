#!/bin/bash
# Простая проверка системы

echo "🔍 ИНФОРМАЦИЯ О СИСТЕМЕ"
echo "======================"

# Операционная система
echo "ОС: $(uname -s) $(uname -r)"

# Архитектура
echo "Архитектура: $(uname -m)"

# Проверка Ollama
echo -n "Ollama: "
if command -v ollama &> /dev/null; then
    echo "установлена ($(ollama --version 2>/dev/null || echo 'версия не определена'))"
else
    echo "не установлена"
fi

# Проверка свободного места
echo -n "Свободное место: "
df -h . | tail -1 | awk '{print $4}'

echo ""
echo "✅ Проверка завершена"
echo "💡 Для установки AI выполните команды из файла INSTALL.txt"
