#!/bin/bash
# AI Coder Menu v2.0 - с проверкой и установкой моделей

MODELS_DIR="models"
OLLAMA_MODELS_DIR="$HOME/.ollama/models"

# Создаём папку для моделей если нет
mkdir -p "$MODELS_DIR"

# Функция проверки установлена ли модель
check_model() {
    local model_name=$1
    if ollama list | grep -q "$model_name"; then
        return 0  # модель установлена
    else
        return 1  # модель не установлена
    fi
}

# Функция установки модели
install_model() {
    local model_name=$1
    echo "📥 Устанавливаю $model_name..."
    echo "Это займёт некоторое время..."
    
    # Сохраняем модель в нашу папку через символическую ссылку
    ollama pull "$model_name"
    
    if [ $? -eq 0 ]; then
        echo "✅ $model_name установлена!"
        return 0
    else
        echo "❌ Ошибка при установке $model_name"
        return 1
    fi
}

# Функция запуска модели
run_model() {
    local model_name=$1
    local description=$2
    
    echo ""
    echo "🤖 $description"
    echo "⚡ Модель: $model_name"
    
    if check_model "$model_name"; then
        echo "✅ Модель установлена, запускаю..."
        echo "────────────────────────────────────"
        ollama run "$model_name"
    else
        echo "❌ Модель не установлена!"
        echo ""
        read -p "Установить сейчас? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_model "$model_name"
            if [ $? -eq 0 ]; then
                echo "🚀 Запускаю модель..."
                echo "────────────────────────────────────"
                ollama run "$model_name"
            fi
        else
            echo "⏭️  Пропускаем эту модель"
            read -p "Нажмите Enter для продолжения..."
        fi
    fi
}

# Главное меню
main_menu() {
    while true; do
        clear
        echo "╔════════════════════════════════════════╗"
        echo "║         🤖 AI CODER MENU v2.0         ║"
        echo "║    с автоматической установкой моделей  ║"
        echo "╚════════════════════════════════════════╝"
        echo ""
        echo "🚀 ЗАПУСТИТЬ МОДЕЛЬ:"
        echo ""
        echo "1. DeepSeek-Coder 1.3B ⚡⚡⚡⚡⚡"
        echo "   (самая быстрая, для начала)"
        echo ""
        echo "2. DeepSeek-Coder 6.7B ⚡⚡⚡"
        echo "   (баланс скорости/качества)"
        echo ""
        echo "3. Qwen2.5-Coder 7B ⚡⚡"
        echo "   (современная, 20+ языков)"
        echo ""
        echo "4. CodeLlama 7B ⚡⚡⚡"
        echo "   (классическая, проверенная)"
        echo ""
        echo "5. Codestral ⚡⚡⚡"
        echo "   (от Mistral AI, эффективная)"
        echo ""
        echo "🔧 УПРАВЛЕНИЕ:"
        echo ""
        echo "6. 📦 Показать установленные модели"
        echo "7. 📥 Установить все модели"
        echo "8. 🗑️  Удалить модель"
        echo "9. 🔍 Проверить систему"
        echo "0. 🚪 Выход"
        echo ""
        
        read -p "Выберите пункт [0-9]: " choice
        
        case $choice in
            1)
                run_model "deepseek-coder:1.3b" "DeepSeek-Coder 1.3B - самая быстрая модель"
                ;;
            2)
                run_model "deepseek-coder:6.7b" "DeepSeek-Coder 6.7B - отличный баланс"
                ;;
            3)
                run_model "qwen2.5-coder:7b" "Qwen2.5-Coder 7B - современная модель"
                ;;
            4)
                run_model "codellama:7b" "CodeLlama 7B - классическая модель"
                ;;
            5)
                run_model "codestral:latest" "Codestral - от Mistral AI"
                ;;
            6)
                clear
                echo "📦 УСТАНОВЛЕННЫЕ МОДЕЛИ:"
                echo "───────────────────────"
                ollama list
                echo ""
                echo "💡 Не установленные модели можно установить через меню"
                read -p "Нажмите Enter для продолжения..."
                ;;
            7)
                clear
                echo "📥 УСТАНОВКА ВСЕХ МОДЕЛЕЙ"
                echo "─────────────────────────"
                echo "Будут установлены 5 моделей:"
                echo "1. deepseek-coder:1.3b"
                echo "2. deepseek-coder:6.7b"
                echo "3. qwen2.5-coder:7b"
                echo "4. codellama:7b"
                echo "5. codestral:latest"
                echo ""
                echo "⚠️  Это займёт много времени и места (~20 ГБ)"
                echo ""
                read -p "Продолжить? (y/n): " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    install_model "deepseek-coder:1.3b"
                    install_model "deepseek-coder:6.7b"
                    install_model "qwen2.5-coder:7b"
                    install_model "codellama:7b"
                    install_model "codestral:latest"
                    echo "✅ Все модели установлены!"
                    read -p "Нажмите Enter для продолжения..."
                fi
                ;;
            8)
                clear
                echo "🗑️  УДАЛЕНИЕ МОДЕЛИ"
                echo "──────────────────"
                echo "Установленные модели:"
                ollama list
                echo ""
                read -p "Введите имя модели для удаления: " model_to_remove
                if [ -n "$model_to_remove" ]; then
                    echo "Удаляю $model_to_remove..."
                    ollama rm "$model_to_remove"
                    echo "✅ Модель удалена"
                fi
                read -p "Нажмите Enter для продолжения..."
                ;;
            9)
                ./check-system.sh
                read -p "Нажмите Enter для продолжения..."
                ;;
            0)
                echo "👋 До свидания!"
                exit 0
                ;;
            *)
                echo "❌ Неверный выбор!"
                sleep 1
                ;;
        esac
    done
}

# Проверяем, установлен ли Ollama
if ! command -v ollama &> /dev/null; then
    echo "❌ Ollama не установлена!"
    echo ""
    echo "Для работы меню необходимо установить Ollama:"
    echo ""
    echo "1. Для macOS/Linux:"
    echo "   curl -fsSL https://ollama.ai/install.sh | sh"
    echo ""
    echo "2. Для Windows:"
    echo "   Скачайте с https://ollama.com/download/windows"
    echo ""
    echo "После установки перезапустите меню."
    exit 1
fi

# Запускаем главное меню
main_menu
